# vCard - Personal portfolio

vCard is a fully responsive personal portfolio website, responsive for all devices, built using HTML, CSS, and JavaScript.

## License

This project is **free to use** and does not contains any license.
